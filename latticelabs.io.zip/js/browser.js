window.CodeMirror = require("codemirror");
require("./index");
